
<?php $__env->startSection('content'); ?>
    <div class="main-content mt-5">
        <div class="row">
            <div class="col-12">
                <div class="card mb-5">
                    <div class="card-header">
                        <span style="font-weight:600;font-size: 20px;">All Stuff</span>

                       
                            <a href="<?php echo e(route('stuffs.create')); ?>" class="btn btn-primary"
                                style="float: right; margin-right:10px;">Create User</a>
                    

                    </div>
                    <div class="card-body">
                        <table class="table table-striped table-bordered border-dark">
                            <thead>
                                <tr>
                                    <th scope="col" style="width:5%; text-align:center;">ID</th>
                                    <th scope="col" style="width:10%; text-align:center;">Name</th>
                                    <th scope="col" style="width:10%; text-align:center;">Email</th>
                                    <th scope="col" style="width:15%; text-align:center;">Publish Date</th>
                                    <th scope="col" style="width:20%; text-align:center;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $stuffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stuff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row" style="text-align: center;"><?php echo e($stuff->id); ?></th>


                                        <td style="text-align: center;"><?php echo e($stuff->name); ?></td>

                                        <td style="text-align: center;"><?php echo e($stuff->email); ?>

                                        </td>

                                    
                                        <td style="text-align: center;"><?php echo e(date('d-m-Y', strtotime($stuff->created_at))); ?>

                                        </td>

                                        <td style="text-align: center;">

                                            <div class="d-flex">
                                                <div>
                                                    

                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $stuff)): ?>
                                                        <a href="<?php echo e(route('stuffs.edit', $stuff->id)); ?>"
                                                            class="btn btn-sm btn-success me-2">Edit</a>
                                                    <?php endif; ?>

                                                </div>

                                                <div>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $stuff)): ?>
                                                    <form action="<?php echo e(route('stuffs.destroy', $stuff->id)); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button class="btn btn-sm btn-danger" style="">Delete</button>
                                                    </form>
                                                    <?php endif; ?>

                                                </div>
                                            </div>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>

                        

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Inventory Management App\resources\views/stuffs/index.blade.php ENDPATH**/ ?>